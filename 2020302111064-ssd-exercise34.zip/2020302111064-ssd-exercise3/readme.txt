Catfish.java  向右游动，获取栏数和鱼的图片
HtmlAnchor.java 创建一个链接
HtmlImage.java 引用图片
HtmlTable.java 创建表单
Simulation.java 模拟鱼的游动
SimulationServlet.java 负责整合其它类并且响应网页的请求
SimulationView.java 负责创建网页界面

修改了Catfish.java;
HtmlImage.java;
SimulationView.java